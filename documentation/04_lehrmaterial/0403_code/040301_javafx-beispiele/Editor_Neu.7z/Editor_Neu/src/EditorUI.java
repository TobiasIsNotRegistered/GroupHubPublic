import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

/**
 * Created by Tobias Sigel on 21.06.2016.
 */
public class EditorUI extends BorderPane {

    private double opcty;
    DecimalFormat df = new DecimalFormat("#.## %");

    private Slider opacity = new Slider(0.10, 1.00, 1.00);
    private Button quicksaveButton = createNewButton("quicksave");
    private Button chooseStandardDirectoryButton = createNewButton("Directory");
    private Button createNewFile = createNewButton("new File");
    private CheckBox hideListCheckBox = new CheckBox("hide List");
    private CheckBox setOnTop = new CheckBox("alwaysOnTop");

    private MenuBar menu = new MenuBar();
    private Menu file = new Menu("File");
    private Menu view = new Menu("View");
    private MenuItem open = new MenuItem("open File");
    private MenuItem quicksave = new MenuItem("quicksave");
    private MenuItem save = new MenuItem("save File");
    private MenuItem exit = new MenuItem("close");
    private MenuItem hideList = new MenuItem("hide List");
    private MenuItem hideButtons = new MenuItem("hide Buttons");
    private MenuItem showButtons = new MenuItem("show Buttons");

    private Separator separator1 = new Separator(Orientation.HORIZONTAL);
    private Separator separator2 = new Separator(Orientation.VERTICAL);
    private Separator separator3 = new Separator(Orientation.HORIZONTAL);
    private Separator separator4 = new Separator(Orientation.VERTICAL);

    private VBox topPane = new VBox();
    private HBox outerLeftPane = new HBox();
    private VBox leftPaneButtons = new VBox();
    private VBox leftPaneList = new VBox();
    private VBox bottomPane = new VBox();

    private TextField showPath = new TextField("");
    private TextArea textArea = new TextArea("");
    private Label statusBar = new Label("");
    private Label opacityDescr = new Label("Opacity: 100%");
    private Label pathDescr = new Label("aktueller Ordner: ");
    private Label dataDescr = new Label("Dateien: ");

    private ListView<File> list = new ListView();
    private ObservableList<File> data = FXCollections.observableArrayList();
    private SelectionModel<File> selection = list.getSelectionModel();

    private Insets insetsSep2 = new Insets(15,3,15,5); //Separatoren
    private Insets insetsSep1 = new Insets(3,15,0,15);
    private Insets insetsLeftPane = new Insets(0, 2, 0, 7);

    public EditorUI(Editor editor){
        addEvents(editor);
        initializeSettings(editor);
        layoutEverything();
        addChildren();
    }

    public void addChildren(){
        leftPaneButtons.getChildren().addAll(opacityDescr, opacity, createNewFile, quicksaveButton, chooseStandardDirectoryButton, hideListCheckBox, setOnTop);
        bottomPane.getChildren().addAll(separator1, statusBar);
        leftPaneList.getChildren().addAll(pathDescr, showPath, dataDescr, list);
        outerLeftPane.getChildren().addAll(leftPaneButtons);
        menu.getMenus().addAll(file,view);
        topPane.getChildren().addAll(menu, separator3);

        file.getItems().addAll(open,quicksave, save, exit);
        view.getItems().addAll(hideList, hideButtons, showButtons);

        leftProperty().setValue(outerLeftPane);
        centerProperty().setValue(textArea);
        bottomProperty().setValue(bottomPane);
        topProperty().setValue(topPane);
        rightProperty().setValue(separator4);
    }

    public void layoutEverything(){

        leftPaneList.setSpacing(5);
        leftPaneButtons.setAlignment(Pos.CENTER);
        separator2.setPadding(insetsSep2);
        separator1.setPadding(insetsSep1);
        separator1.setOpacity(0);
        separator3.setPadding(insetsSep1);
        separator3.setOpacity(0);
        separator4.setOpacity(0);
        leftPaneButtons.setSpacing(5); //Abstände zwischen den Buttons
        leftPaneButtons.setPadding(insetsLeftPane);

        outerLeftPane.setPadding(new Insets(0,5,0,0));
        statusBar.setPadding(new Insets(0,0,2,5));
        //this.setPadding(insetsBorderPane); //Rahmen um Applikation
    }

    public void initializeSettings(Editor editor){
        hideListCheckBox.setSelected(true);
        textArea.setText(editor.getBase());
        statusBar.setText(editor.getStatus());
        updateList(editor);
        textArea.setWrapText(true);
        list.setEditable(false);
        statusBar.setPrefHeight(20);
        list.setPrefWidth(250);
    }



    public void addEvents(Editor editor){

        opacity.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                opcty=newValue.doubleValue();
                opacityDescr.setText("Opacity: " + df.format(opcty)); //df = object of Class DecimalFormat, see at top
                ((Stage)getScene().getWindow()).setOpacity(opcty);
                }

        });

        createNewFile.setOnAction(event -> {
            textArea.setText(editor.iniateNewFile());
            statusBar.setText(editor.getStatus());
        });

        setOnTop.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                if(newValue){
                    try {
                        ((Stage)getScene().getWindow()).setAlwaysOnTop(true);
                    }catch(NullPointerException e){
                        System.out.println("Funktioniert noch nicht!");
                    }
                }else{
                    try {
                        ((Stage)getScene().getWindow()).setAlwaysOnTop(false);
                    }catch(NullPointerException e){
                        System.out.println("Funktioniert noch nicht!");
                    }
                }
            }
        });

        selection.selectedIndexProperty().addListener(e -> {
            editor.setCurrentFile(selection.getSelectedItem());
            try{
                textArea.setText(editor.readFile());
                statusBar.setText(editor.getStatus());
            }catch(IOException o){
                System.out.println("selection.selectedIndexProperty().addListener -> catched IOEception");
            }
        });

        chooseStandardDirectoryButton.setOnAction(event -> {
            editor.chooseStandardDirectory();
            try {
                updateList(editor);
            }catch(NullPointerException e){
                //do nothing because it's irrelevant anyway
            }
        });

        hideListCheckBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                if (newValue){
                    outerLeftPane.getChildren().remove(leftPaneList);
                    outerLeftPane.getChildren().remove(separator2);
                }else{
                    outerLeftPane.getChildren().add(outerLeftPane.getChildren().size(), separator2);
                    outerLeftPane.getChildren().add(outerLeftPane.getChildren().size(), leftPaneList);
                }
            }
        });

        textArea.selectionProperty().addListener(event ->{
           editor.setBase(textArea.textProperty().get());
            statusBar.setText(editor.getStatus());
        });

        save.setOnAction(event ->{
            try {
                editor.saveFile();
                statusBar.setText(editor.getStatus());
            }
            catch(IOException e){
                System.out.println("save.setOnAction -> catched IOException.");
            }
        });

        open.setOnAction(event ->{
            try {
                textArea.setText(editor.openFile());
                editor.setStandardDirectory(editor.getCurrentFile().getParentFile());
                statusBar.setText(editor.getStatus());
                updateList(editor);
            }
            catch(IOException e){
                System.out.println("open.setOnAction -> catched IOException.");
            }
            catch(NullPointerException e){
                //do nothing
                //System.out.println("open.setOnAction -> catched NullPointerException.");
                statusBar.setText(editor.getStatus());

            }
        });

        exit.setOnAction(event -> {
            System.exit(0);
        });

        quicksaveButton.setOnAction(event -> quicksave.fire()); //wenn dieser Button gedrückt wird, wird quicksave gedrückt!

        quicksave.setOnAction(event -> {
                try {
                    editor.quickSaveFile();
                    statusBar.setText(editor.getStatus());
                }
                catch(IOException e){
                    save.fire();
                    System.out.println("quicksave.setOnAction -> catched IOException");
                }

        });

        hideButtons.setOnAction(event -> {
            outerLeftPane.getChildren().remove(leftPaneButtons);
        });

        showButtons.setOnAction(event -> {
            outerLeftPane.getChildren().add(leftPaneButtons);
        });
    }



    public Button createNewButton(String name){
        Button button = new Button(name);
        button.setMaxHeight(30);
        button.setMaxWidth(80);
        button.setMinWidth(80);
        button.setMinHeight(30);
        return button;
    }

    public void updateList(Editor editor){
        data = FXCollections.observableArrayList();
        for (int i = 0; i < editor.getStandardDirectory().listFiles().length; i++) {
            data.add(i, editor.getStandardDirectory().listFiles()[i]);
            //data.set(i,editor.getStandardDirectory().listFiles()[i]);
        }
        list.setItems(data);
        try {
            showPath.setText(editor.getStandardDirectory().getCanonicalPath());
        }catch (IOException e){
            System.out.println("updateList() -> catched IOException");
        }
    }
}
