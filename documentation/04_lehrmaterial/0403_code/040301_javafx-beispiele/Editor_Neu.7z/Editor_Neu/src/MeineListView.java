import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;

import java.io.File;

/**
 * Created by Tobias Sigel on 27.06.2016.
 */
public class MeineListView extends ListCell<File> {

    /* must have tried to make my own ListView, but doesn't work. Ignore if possible */
    @Override
    protected void updateItem(File item, boolean empty) {
        super.updateItem(item, empty);
        if (!empty) {
            setText("aaa"); //item.getName()
        }
    }
}
