import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;

import java.io.File;

/**
 * Created by Tobias Sigel on 27.06.2016.
 */
public class MeineListView extends ListCell<File> {
    @Override
    protected void updateItem(File item, boolean empty) {
        super.updateItem(item, empty);
        if (!empty) {
            setText(item.getName());
        }
    }
}
