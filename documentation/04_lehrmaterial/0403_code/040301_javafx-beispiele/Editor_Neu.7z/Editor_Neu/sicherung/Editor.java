import javafx.scene.control.TextArea;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Tobias Sigel on 21.06.2016.
 */
public class Editor extends main{

    private File currentFile;
    private FileChooser fc = new FileChooser();
    private File standardDirectory;
    private DirectoryChooser dc = new DirectoryChooser();

    private String base;
    private String status;

    public Editor(String data, String name, File init){
        if(data == "failed"){
           base = iniateNewFile();
        }else{
            base = data;
        }
            status = name + " \t" + "  ->  started";
            standardDirectory = init.getParentFile();
    }

    public String iniateNewFile(){
        base = "";
        DateFormat dateFormatYear = new SimpleDateFormat("dd.MM.yyyy");
        DateFormat dateFormatHours = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date();
        String datum =  dateFormatYear.format(date);
        String hours =  dateFormatHours.format(date);
        String result = "[new File]" + " - " + datum + " - " + hours + "\n" + "_____________________";
        currentFile = null;
        standardDirectory = null;
        setStatus("new File has been initiated");
        return result;
    }

    public void saveFile() throws IOException{

        File temp = currentFile;
        if(currentFile!=null){fc.setInitialDirectory(new File(currentFile.getParent()));}
        currentFile = fc.showSaveDialog(new Stage());
        quickSaveFile();
    }

    public void quickSaveFile() throws IOException{
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(currentFile));
            bw.write(base);
            bw.close();
            setStatus(currentFile.getName() +  " \t" + "  ->  saving File successful");
            //setStandardDirectory(currentFile.getParentFile());
        }catch(NullPointerException e){
            setStatus("saving File cancelled");
        }
    }

    public String openFile() throws IOException{
        //falls schonmal "openFile" ausgeführt wurde, wird initialDirectory zur letztgewählten Directory!
        fc.setInitialDirectory(new File(currentFile.getParent()));
        currentFile = fc.showOpenDialog(new Stage()); //new Stage?
        return readFile();
    }

    public String readFile() throws IOException{

        String line = " ";
        String temp = base; //falls openingFile abgebrochen wird, soll das alte wieder angezeigt werden
        base = new String();

        try {
            BufferedReader br = new BufferedReader(new FileReader(currentFile));

            while((line = br.readLine()) != null){ //dies muss so ausgeführt werden, da br.readLine jeweils die nächste Zeile zurückgibt, sodass line zwar != null, br.readLine aber doch!
                base += line;
                base += "\n";
            }
            setStatus(currentFile.getName() +  " \t" + "  ->  opening file successful");
            br.close();

        }catch(NullPointerException e){
            setStatus("opening file canceled.");
            base = temp;
        }
        return base;
    }

    public void setAlwaysOnTop(boolean alwaysOnTop){
        Stage x = new Stage();
        x.setAlwaysOnTop(alwaysOnTop);
        x = mainStage;

        x.setTitle(title);
        x.setScene(scene);
        x.show();

        System.out.println("funktioniert noch nicht! siehe: Editor: setAlwaysOnTop");
    }

    public void chooseStandardDirectory(){
        if(currentFile!=null){dc.setInitialDirectory(new File(currentFile.getParent()));}
        standardDirectory = dc.showDialog(new Stage());
    }

    public String getBase(){
        return base;
    }

    public void setBase(String s){
        base = s;
    }

    public String getStatus(){
        return status;
    }

    public void setStatus(String s){
        status = s;
    }

    public File getCurrentFile(){
        return currentFile;
    }

    public void setCurrentFile(File f){
        currentFile = f;
    }

    public void setStandardDirectory(File f){
        standardDirectory = f;
    }

    public File getStandardDirectory(){
        return standardDirectory;
    }






}
