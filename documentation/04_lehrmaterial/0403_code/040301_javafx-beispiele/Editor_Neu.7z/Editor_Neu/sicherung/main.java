import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.text.DecimalFormat;

import static javafx.application.Application.launch;

/**
 * Created by Tobias Sigel on 21.06.2016.
 */
public class main extends Application {

    Editor editor;
    EditorUI rootPanel;
    Stage mainStage;
    Scene scene;
    String initData; //eingelesene Daten von init();
    String initFileName; //Name vom eingelesenen File
    String title = "NewTextEditor";
    File init; //Pfad der eingelesenen Datei


    @Override
    public void start(Stage primaryStage){
        mainStage = primaryStage;
        editor = new Editor(initData, initFileName, init);
        editor.setCurrentFile(init);
        rootPanel = new EditorUI(editor); //was before: Parent rootpanel = new EditorUI(editor);
        scene = new Scene(rootPanel);
        mainStage.setTitle(title);
        mainStage.setScene(scene);
        mainStage.show();
    }

    @Override
    public void init() throws IOException{
        File f = new File("init.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            initData = br.readLine(); //hier ist stringInit der Pfad der anzuzeigenden Datei
            init = new File(initData);
            br = new BufferedReader(new FileReader(init));
            String line;
            initData = ""; //hier wird stringInit geleert, damit es überschrieben werden kann

            while((line = br.readLine()) != null) {
                initData += line;
                initData += "\n";
            }

            initFileName = init.getName();
            br.close();
        }catch(NullPointerException e){
            initData = "failed";
            initFileName = "init.txt contained no readable filepath";
            init = new File("C:\\Users");
            System.out.println("init() -> NullPointerException: br.readLine() read null (init.txt ist leer)");
        }catch(FileNotFoundException e){
            initData = "failed";
            initFileName = "init.txt: FileNotFoundException";
            init = new File("C:\\Users");
            System.out.println("init() -> FileNotFoundExcpetion: init.txt extistiert nicht /oder/: Pfad ist da, stellt aber kein File dar (wahrscheinlich ein Ordner-Verzeichnis).");
        }
    }

    @Override
    public void stop() throws IOException{
        File f = new File("init.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        try {
            bw.write(editor.getCurrentFile().getCanonicalPath());
        }
        catch(NullPointerException e){
            System.out.println("stop() -> NullPointerException: no currentFile found.");
        }
        bw.close();
        mainStage.close();

    }

    public static void main(String[] args){
        launch(args);
    }

}
