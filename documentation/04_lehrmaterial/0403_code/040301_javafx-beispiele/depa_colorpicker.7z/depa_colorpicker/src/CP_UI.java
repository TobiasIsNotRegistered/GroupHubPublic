import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Created by tobi6 on 22.09.2017.
 */
public class CP_UI extends BorderPane {

    private MenuBar menu = new MenuBar();
    private Menu file = new Menu("File");
    private Menu attributes = new Menu("Attributes");
    //private MenuItem open = new MenuItem("open File");
    //private MenuItem quicksave = new MenuItem("quicksave");

    private VBox vb_upperContainer = new VBox();
    private VBox hb_centerContainer = new VBox();
    private HBox hb_lowerContainer = new HBox();

    public TextField statusbar = createTextField("Welcome!");

    private HBox hb_red = new HBox();
    private HBox hb_green = new HBox();
    private HBox hb_blue = new HBox();

    private Rectangle rect_red = new Rectangle(50,50,25,25);
    private Rectangle rect_green = new Rectangle(50,50,25,25);
    private Rectangle rect_blue = new Rectangle(50,50,25,25);

    private Slider sl_red = createSlider();
    private Slider sl_green = createSlider();
    private Slider sl_blue = createSlider();

    private TextField tf_red = createTextField("");
    private TextField tf_green = createTextField("");
    private TextField tf_blue = createTextField("");

    private Label la_red = createLabel("");
    private Label la_green = createLabel("");
    private Label la_blue = createLabel("");

    private Rectangle rect = new Rectangle(50,50,250,250);

    private VBox vb_checkBox_container = new VBox();
    private CheckBox ch_red = new CheckBox("red");
    private CheckBox ch_green = new CheckBox("green");
    private CheckBox ch_blue = new CheckBox("blue");
    private CheckBox ch_cyan = new CheckBox("cyan");
    private CheckBox ch_magenta = new CheckBox("magenta");
    private CheckBox ch_yellow = new CheckBox("yellow");
    private CheckBox ch_black = new CheckBox("black");

    private VBox vb_button_container = new VBox();
    private Button bt_brighter = new Button("brighter (1:1)");
    private Button bt_darker = new Button("darker (1:1)");
    private Button bt_brighter2 = new Button("brighter");
    private Button bt_darker2 = new Button("darker");

    private Insets insets1 = new Insets(15,15,15,15);
    private Separator separator1 = new Separator(Orientation.VERTICAL);

    public CP_UI(ColorPicker cp){
        addChildren();
        setUpThisContainer();
        styleStuff();
        setUpBindings(cp);

        update(cp);
    }

    public void addChildren(){
         menu.getMenus().addAll(file, attributes);

         hb_red.getChildren().addAll(rect_red,sl_red, tf_red, la_red);
         hb_green.getChildren().addAll(rect_green,sl_green, tf_green, la_green);
         hb_blue.getChildren().addAll(rect_blue,sl_blue, tf_blue, la_blue);

         vb_checkBox_container.getChildren().addAll(ch_red, ch_green, ch_blue, ch_cyan, ch_magenta, ch_yellow, ch_black);

         vb_button_container.getChildren().addAll(bt_brighter, bt_darker, bt_brighter2, bt_darker2);

         vb_upperContainer.getChildren().addAll(menu);
         hb_centerContainer.getChildren().addAll(hb_red, hb_green, hb_blue, statusbar);
         hb_lowerContainer.getChildren().addAll(rect, vb_checkBox_container,separator1, vb_button_container);

    }

    public void setUpThisContainer(){
        topProperty().setValue(vb_upperContainer);
        centerProperty().setValue(hb_centerContainer);
        bottomProperty().set(hb_lowerContainer);
    }

    public void styleStuff(){

        statusbar.setPadding(new Insets(0,25,0,25));
        statusbar.setPrefWidth(500);
        statusbar.setAlignment(Pos.CENTER);
        statusbar.setEditable(false);
        statusbar.setStyle("-fx-background-color: white");

        hb_centerContainer.setAlignment(Pos.CENTER);

        rect_red.setFill(new    Color(1.0,      0,      0,      1.0));
        rect_green.setFill(new  Color(0,        1.0,    0,      1.0));
        rect_blue.setFill(new   Color(0,        0,      1.0,    1.0));

        rect_red.setArcWidth(100);
        rect_red.setArcHeight(100);
        rect_green.setArcWidth(100);
        rect_green.setArcHeight(100);
        rect_blue.setArcWidth(100);
        rect_blue.setArcHeight(100);

        hb_red.setPadding(insets1);
        hb_red.setSpacing(15);
        hb_red.setAlignment(Pos.CENTER);

        hb_green.setPadding(insets1);
        hb_green.setSpacing(15);
        hb_green.setAlignment(Pos.CENTER);

        hb_blue.setPadding(insets1);
        hb_blue.setSpacing(15);
        hb_blue.setAlignment(Pos.CENTER);

        bt_brighter.setPrefWidth(100);
        bt_darker.setPrefWidth(100);
        bt_brighter2.setPrefWidth(100);
        bt_darker2.setPrefWidth(100);

        separator1.setPadding(insets1);

        vb_checkBox_container.setAlignment(Pos.TOP_LEFT);
        vb_checkBox_container.setSpacing(25);
        vb_checkBox_container.setPadding(insets1);
        vb_button_container.setAlignment(Pos.CENTER);
        vb_button_container.setSpacing(25);

        hb_lowerContainer.setPadding(insets1);
        hb_lowerContainer.setAlignment(Pos.CENTER);

    }



    public void setUpBindings(ColorPicker cp){

        //******************** TextFields ***********************

        tf_red.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                try {
                    cp.setColorR(Float.parseFloat(newValue) / 255);
                }catch(IllegalArgumentException e){
                    System.out.println("Only Numbers are valid entries");
                }
                update(cp);
            }
        });

        tf_green.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                try {
                    cp.setColorG(Float.parseFloat(newValue) / 255);
                }catch(IllegalArgumentException e){
                    System.out.println("Only Numbers are valid entries");
                }
                update(cp);
            }
        });

        tf_blue.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                try {
                    cp.setColorB(Float.parseFloat(newValue) / 255);
                }catch(IllegalArgumentException e){
                    System.out.println("Only Numbers are valid entries");
                }
                update(cp);
            }
        });

        //******************** SLIDERS ***********************

        sl_red.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                cp.setColorR(newValue.floatValue()/255);
                update(cp);

            }
        });

        sl_green.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                cp.setColorG(newValue.floatValue()/255);
                update(cp);
            }
        });

        sl_blue.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                cp.setColorB(newValue.floatValue()/255);
                update(cp);
            }
        });

        //******************** Checkboxes ***********************

        ch_red.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)1.0);
                cp.setColorG((float)0.0);
                cp.setColorB((float)0.0);

                toggleDisableAll(newValue);
                ch_red.setDisable(false);
                update(cp);

            }
        });

        ch_green.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)0.0);
                cp.setColorG((float)1.0);
                cp.setColorB((float)0.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_green.setDisable(false);
            }
        });


        ch_blue.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)0.0);
                cp.setColorG((float)0.0);
                cp.setColorB((float)1.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_blue.setDisable(false);
            }
        });

        ch_cyan.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)0.0);
                cp.setColorG((float)1.0);
                cp.setColorB((float)1.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_cyan.setDisable(false);
            }
        });

        ch_magenta.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)1.0);
                cp.setColorG((float)0.0);
                cp.setColorB((float)1.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_magenta.setDisable(false);
            }
        });

        ch_yellow.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)1.0);
                cp.setColorG((float)1.0);
                cp.setColorB((float)0.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_yellow.setDisable(false);
            }
        });

        ch_black.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {

                cp.setColorR((float)0.0);
                cp.setColorG((float)0.0);
                cp.setColorB((float)0.0);

                toggleDisableAll(newValue);
                update(cp);
                ch_black.setDisable(false);
            }
        });

        //******************** Buttons ***********************

        bt_brighter.setOnAction(event -> {
            cp.brighter();

            toggleDisableAll(false);

            for (Node a: vb_checkBox_container.getChildren()) {
                ((CheckBox) a).setSelected(false);
            }

            update(cp);

        });

        bt_darker.setOnAction(event -> {
            cp.darker();

            toggleDisableAll(false);

            for (Node a: vb_checkBox_container.getChildren()) {
                ((CheckBox) a).setSelected(false);
            }

            update(cp);
        });

        bt_brighter2.setOnAction(event -> {
            cp.brighter2();
            update(cp);
            toggleDisableAll(false);

            for (Node a: vb_checkBox_container.getChildren()) {
                 ((CheckBox) a).setSelected(false);
            }

        });

        bt_darker2.setOnAction(event -> {
            cp.darker2();
            update(cp);
            toggleDisableAll(false);

            for (Node a: vb_checkBox_container.getChildren()) {
                 ((CheckBox) a).setSelected(false);
            }

        });
    }

    //******************** Auxiliary ***********************

    public void update(ColorPicker cp){
        sl_red.valueProperty().set(cp.getColorR()*255);
        sl_green.valueProperty().set(cp.getColorG()*255);
        sl_blue.valueProperty().set(cp.getColorB()*255);

        rect.setFill(cp.calculateColor());

        bt_brighter.setDisable(!cp.getMutableUp());
        bt_darker.setDisable(!cp.getMutableDown());

        tf_red.setText(Integer.toString((int)(cp.getColorR()*255)));
        la_red.textProperty().setValue(Integer.toHexString((int)(cp.getColorR()*255)));

        tf_green.setText(Integer.toString((int)(cp.getColorG()*255)));
        la_green.textProperty().setValue(Integer.toHexString((int)(cp.getColorG()*255)));

        tf_blue.setText(Integer.toString((int)(cp.getColorB()*255)));
        la_blue.textProperty().setValue(Integer.toHexString((int)(cp.getColorB()*255)));

        statusbar.setText(cp.getText());

    }

    public void toggleDisableAll(boolean newValue){
        sl_red.setDisable(newValue);
        sl_green.setDisable(newValue);
        sl_blue.setDisable(newValue);

        tf_red.setEditable(!newValue);
        tf_green.setEditable(!newValue);
        tf_blue.setEditable(!newValue);

        for (Node a: vb_checkBox_container.getChildren()) {
            a.setDisable(newValue);
        }
    }

    public Slider createSlider(){
        Slider slider = new Slider();
        slider.setMin(0);
        slider.setMax(255);
        slider.setValue(255);
        slider.setShowTickLabels(false);
        slider.setShowTickMarks(false);
        slider.setMajorTickUnit(50);
        slider.setMinorTickCount(5);
        slider.setBlockIncrement(10);
        slider.setPrefHeight(35);
        slider.setPrefWidth(200);

        return slider;
    }

    public TextField createTextField(String text){
        TextField field = new TextField(text);
        field.setPrefHeight(35);
        field.setPrefWidth(100);
        return field;
    }

    public Label createLabel(String text){
        Label label = new Label(text);
        label.setPadding(new Insets(0,15,0,15));
        label.setPrefHeight(35);
        label.setPrefWidth(100);
        label.setStyle("-fx-background-color: white");

        return label;
    }

}
