import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Created by tobi6 on 22.09.2017.
 */
public class main_starter extends Application {

    ColorPicker colorPicker;
    CP_UI rootpanel;

    Stage mainStage;
    Scene scene;

    String title = "Tobi's ColorPicker";

    @Override
    public void start(Stage primaryStage){
        mainStage = primaryStage;
        colorPicker = new ColorPicker();
        rootpanel = new CP_UI(colorPicker);
        scene = new Scene(rootpanel);

        mainStage.setTitle(title);
        mainStage.setScene(scene);
        mainStage.show();
    }

    @Override
    public void init(){

    }

    @Override
    public void stop(){

    }

    public static void main(String[] args){
        launch(args);
    }

}
