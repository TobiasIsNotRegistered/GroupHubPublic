import javafx.beans.property.Property;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;


/**
 * Created by tobi6 on 22.09.2017.
 */
public class ColorPicker extends main_starter {

    private float colorR;
    private float colorG;
    private float colorB;

    private Paint mainPaint;
    private Color mainColor;

    private boolean mutableUp;
    private boolean mutableDown;

    private String text;

    public ColorPicker(){

        colorR = 1;
        colorG = 1;
        colorB = 1;
    }

    public Paint calculateColor(){
        mutableUp = true;
        mutableDown = true;

        text = Integer.toString((int)(colorR*255)) + "," + Integer.toString((int)(colorG*255)) + "," + Integer.toString((int)(colorB*255));

            try {
                mainColor = new Color(colorR, colorG, colorB, 1.0);
            }catch (IllegalArgumentException e){
                text = "Entered numbers must be in the range of 0 to 255.";
            }

        mainPaint = mainColor;

        if(colorR <= 0.01/2.55  || colorG <= 0.01/2.55 || colorB <= 0.01/2.55 ){
            mutableDown = false;}

        if(colorR >= 1.0 || colorG >= 1.0|| colorB >= 1.0){
            mutableUp = false;
        }

        return mainPaint;
    }

    public Paint brighter(){

        if(mutableUp){
            colorR += 0.01/2.55;
            colorG += 0.01/2.55;
            colorB += 0.01/2.55;
        }

        mainPaint = calculateColor();
        return mainPaint;
    }

    public Paint brighter2(){

        if(colorR < 1.0){colorR+=0.01/2.55;}
        if(colorG < 1.0){colorG+=0.01/2.55;}
        if(colorB < 1.0){colorB+=0.01/2.55;}

        mainPaint = calculateColor();
        return mainPaint;
    }

    public Paint darker(){

        if(mutableDown){
            colorR -= 0.01/2.55;
            colorG -= 0.01/2.55;
            colorB -= 0.01/2.55;
        }

        mainPaint = calculateColor();
        return mainPaint;
    }

    public Paint darker2(){

        if(colorR >= 0.01){colorR-=0.01/2.55;}
        if(colorG >= 0.01){colorG-=0.01/2.55;}
        if(colorB >= 0.01){colorB-=0.01/2.55;}

        mainPaint = calculateColor();
        return mainPaint;
    }

    public float getColorR() {
        return colorR;
    }

    public float getColorG() {
        return colorG;
    }

    public float getColorB() {
        return colorB;
    }

    public void setColorR(float colorR) {
        this.colorR = colorR;
    }

    public void setColorG(float colorG) {
        this.colorG = colorG;
    }

    public void setColorB(float colorB) {
        this.colorB = colorB;
    }

    public boolean getMutableUp(){
        return mutableUp;
    }

    public boolean getMutableDown(){
        return mutableDown;
    }

    public String getText(){
        return text;
    }

    public void setText(String text){
        this.text = text;
    }
}
